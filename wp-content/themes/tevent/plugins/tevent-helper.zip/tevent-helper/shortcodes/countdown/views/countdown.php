<div class="<?php echo esc_attr( $class ); ?>" data-date="<?php echo esc_attr( $atts['end_time'] ); ?>"></div>
